#include "smg.h"
#include "uart.h"
u8 Seg7[17] = { 0x3f,0x06,0x5b,0x4f, 0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x77,0x7c, 0x39,0x5e,0x79,0x71,0x00}; 
void dm(u32 nTime);
void smg_init(void)
{
		GPIO_InitTypeDef GPIO_InitStructure;
	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	  /* Configure PD0 and PD2 in output pushpull mode */
	  GPIO_InitStructure.GPIO_Pin =GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3;
	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	  GPIO_Init(GPIOA, &GPIO_InitStructure);
}
void smg_conf(u8 smg1 ,u8 smg2 , u8 smg3)
{
	
	u8 temp;int i =0;
	temp = Seg7[smg3];
			SCK_H;
			RCK_H;
	for(i=0;i<8;i++)
	{
		if(temp&(0x80))
			SER_H;
		else
			SER_L;
		SCK_H;
		SCK_L;
		SCK_H;		
		temp = temp<<1;
	}
///////////////////	
		temp = Seg7[smg2];
	for(i=0;i<8;i++)
	{
		if(temp&(0x80))
			SER_H;
		else
			SER_L;
		SCK_H;
		SCK_L;
		SCK_H;		
		temp = temp<<1;
	}
/////////////////
		temp = Seg7[smg1];
	for(i=0;i<8;i++)
	{
		if(temp&(0x80))
			SER_H;
		else
			SER_L;
		SCK_H;			
		SCK_L;
		SCK_H;
		temp = temp<<1;
	}
	RCK_H;
	RCK_L;
	RCK_H;	
}
