#ifndef __pwm_h
#define __pwm_h
#include "stm32f10x.h"
void pwm_init(void);
void pwm_conf(u32 fre ,u8 duty,u8 status);
extern u8 pwm_status;
#endif
