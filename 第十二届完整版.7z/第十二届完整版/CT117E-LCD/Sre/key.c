#include "key.h"
#include "led.h"
#include "show.h"
void key_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB, ENABLE);

	  /* Configure PD0 and PD2 in output pushpull mode */
	  GPIO_InitStructure.GPIO_Pin =GPIO_Pin_0|GPIO_Pin_8;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	  GPIO_Init(GPIOA, &GPIO_InitStructure);
		GPIO_InitStructure.GPIO_Pin =GPIO_Pin_1|GPIO_Pin_2;
		 GPIO_Init(GPIOB, &GPIO_InitStructure);
}
u8 key_num,key_flag;
u8 pwm_status;
void key_scan(void)
{
	static int key1_sum,key2_sum,key3_sum,key4_sum;
	if(key1_press == 0)
	{
	key1_sum++;
	if(key1_sum >= 20)
	{
	
	}
	}
	else
	{
		if(key1_sum>1&&key1_sum<20)
		{
		if(screen_status == DATA)
		{
				screen_status = PARA;
		}
		else
		{
		screen_status = DATA;
		}
		}
		key1_sum=0;
	}
/////////////////////////////////////////
	if(key2_press == 0)
	{
	key2_sum++;
	if(key2_sum >= 20)
	{
	
	}
	}
	else
	{
		if(key2_sum>1&&key2_sum<20)
		{
		if(screen_status == PARA)
		{ cnbr_fl+=0.5;
		 vnbr_fl+=0.5;
		 }
		}
		key2_sum=0;
	}
//////////////////////////////////////////
	if(key3_press == 0)
	{
	key3_sum++;
	if(key3_sum >= 20)
	{
	
	}
	}
	else
	{
		if(key3_sum>1&&key3_sum<20)
		{
		if(screen_status == PARA)
		{ cnbr_fl-=0.5;
		 vnbr_fl-=0.5;
		}
		}
		key3_sum=0;
	}
//////////////////////////////////////////
	if(key4_press == 0)
	{
	key4_sum++;
	if(key4_sum >= 20)
	{
	
	}
	}
	else
	{
		if(key4_sum>1&&key4_sum<20)
		{
			if(pwm_status == 1)
			{
			pwm_status=0;
			}
			else
			{
			pwm_status=1;
			}
			if(pwm_status == 1)
			{

				
			}
			else
			{

			}
		}
		key4_sum=0;
	}
}
