#ifndef __uart_h
#define __uart_h
#include "stm32f10x.h"
void uart_init(void);
void uart_print(char *str);
extern char RxBuffer[30];
extern __IO uint8_t RxCounter; 
extern __IO uint8_t PreRxCounter;
extern u8 uart_num,uart_flag;
void uart_handle(void);
typedef struct Car_info_t{

	u8 type;//1 VNBR 0 CNBR
	char num[10];
	char intime[20];
	char outtime[20];
	struct Car_info_t*next;
}Car_info;
extern Car_info* Car_header;
void car_header_init(void);
#endif
