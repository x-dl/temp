#ifndef __led_h
#define __led_h
#include "stm32f10x.h"
void led_init(void);
void led_control(u16 ledx,u8 status);

#define led1 GPIO_Pin_8
#define led2 GPIO_Pin_9
#define led3 GPIO_Pin_10
#define led4 GPIO_Pin_11
#define led5 GPIO_Pin_12
#define led6 GPIO_Pin_13
#define led7 GPIO_Pin_14
#define led8 GPIO_Pin_15
#define ledall 0xff00
#define lock GPIO_Pin_2
#define ON 1
#define OFF 0

#endif
