#include "show.h"
#include "smg.h"
u8 screen_status = DATA,cnbr,vnbr,idle=8;
float cnbr_fl=3.50,vnbr_fl=2.00;
char show_str[20];
void show(void)
{
	if(screen_status == DATA)
	{
	sprintf(show_str,"       Data     ");
	LCD_DisplayStringLine(Line1,(u8*)show_str);
	sprintf(show_str,"   CNBR:%d     ",cnbr);
	LCD_DisplayStringLine(Line3,(u8*)show_str);
	sprintf(show_str,"   VNBR:%d     ",vnbr);
	LCD_DisplayStringLine(Line5,(u8*)show_str);
	sprintf(show_str,"   IDLE:%d     ",idle);
	LCD_DisplayStringLine(Line7,(u8*)show_str);
	}
	else if(screen_status == PARA)
	{
	sprintf(show_str,"       Para     ");
	LCD_DisplayStringLine(Line1,(u8*)show_str);
	sprintf(show_str,"   CNBR:%.2f     ",cnbr_fl);
	LCD_DisplayStringLine(Line3,(u8*)show_str);
	sprintf(show_str,"   VNBR:%.2f     ",vnbr_fl);
	LCD_DisplayStringLine(Line5,(u8*)show_str);
	sprintf(show_str,"                           ");
	LCD_DisplayStringLine(Line7,(u8*)show_str);
	}
	led_control(ledall,OFF);
	if(pwm_status ==1)
		led_control(led2,ON);
	else
		led_control(led2,OFF);
	if(idle == 0)
		led_control(led1,OFF);
	else
	led_control(led1,ON);
	

}
