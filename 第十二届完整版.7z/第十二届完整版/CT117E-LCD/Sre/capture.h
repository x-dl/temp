#ifndef __capture_h
#define __capture_h
#include "stm32f10x.h"
extern __IO uint32_t TIM2_Ch2_Freq;
extern __IO uint32_t TIM2_Ch3_Freq;
void capture_init(void);
#endif
