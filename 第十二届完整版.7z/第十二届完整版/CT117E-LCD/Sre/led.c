#include "led.h"
void led_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD|RCC_APB2Periph_GPIOC, ENABLE);

	  /* Configure PD0 and PD2 in output pushpull mode */
	  GPIO_InitStructure.GPIO_Pin =ledall;
	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	  GPIO_Init(GPIOC, &GPIO_InitStructure);
		GPIO_InitStructure.GPIO_Pin =lock;
		 GPIO_Init(GPIOD, &GPIO_InitStructure);
		led_control(ledall,OFF);
}
void led_control(u16 ledx,u8 status)
{
	if(status == ON)
	{
	GPIO_ResetBits(GPIOC,ledx);
	GPIO_SetBits(GPIOD,lock);
	GPIO_ResetBits(GPIOD,lock);
	}
	else
	{
		GPIO_SetBits(GPIOC,ledx);
	GPIO_SetBits(GPIOD,lock);
	GPIO_ResetBits(GPIOD,lock);
	}
}
