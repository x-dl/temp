#ifndef __show_h
#define __show_h
#include "stm32f10x.h"
#include "lcd.h"
#include "led.h"
#include "key.h"
#include "uart.h"
#include "pwm.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
void show(void);
#define PARA (1<<1)
#define DATA (1<<2)
extern u8 screen_status,cnbr,vnbr,idle;
extern float cnbr_fl,vnbr_fl;
#endif
