#include "uart.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "show.h"
void uart_init(void)
{
	 NVIC_InitTypeDef NVIC_InitStructure;
USART_InitTypeDef USART_InitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA |RCC_APB2Periph_AFIO, ENABLE);

  /* Enable USARTz Clock */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);  
	 
  
  /* Enable the USARTy Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
	
	  /* Configure USARTy Rx as input floating */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
    
  
  /* Configure USARTy Tx as alternate function push-pull */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

	USART_InitStructure.USART_BaudRate = 9600;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	
	USART_Init(USART2, &USART_InitStructure);
  /* Enable USARTy Receive and Transmit interrupts */
  USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);


  /* Enable the USARTy */
  USART_Cmd(USART2, ENABLE);

}
void uart_print(char *str)
{
	while(*str)
	{
		USART_SendData(USART2,*str);
		while(!USART_GetFlagStatus(USART2,USART_FLAG_TC));
		str++;
	}
}
char RxBuffer[30];
__IO uint8_t RxCounter; 
__IO uint8_t PreRxCounter;
u8 uart_num,uart_flag;
void USART2_IRQHandler(void)
{
  if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
  {
    /* Read one byte from the receive data register */
    RxBuffer[RxCounter++] = USART_ReceiveData(USART2);
  }
  
}
//////////////////////////////////////////////////
Car_info* Car_header;
void car_header_init(void)
{
	Car_header = (Car_info*)malloc(sizeof(Car_info));
	memset(Car_header,0,sizeof(Car_info));
}
Car_info* car_create(void)
{
	Car_info* temp =(Car_info*)malloc(sizeof(Car_info));
	if(temp ==0)
	{
		return 0;
	}
	memset(temp,0,sizeof(Car_info));
	return temp;
}
void car_delete(char* str)
{
	Car_info* temp = Car_header;
	Car_info* pretemp = Car_header;
	while(temp->next)
	{
	pretemp =temp;
	temp = temp ->next;
	if(strcmp(str,temp->num)==0)
	{
		pretemp->next = temp->next;
		free(temp);
		return;
	}
	
	}

}
Car_info* car_find(char* str)
{
Car_info* temp = Car_header;
	while(temp->next)
	{
	temp = temp ->next;
	if(strcmp(str,temp->num)==0)
	{
		return temp ;
	}
	}
	return 0;
}
void car_add(Car_info* temp)
{
	Car_info* temp1 = Car_header;
	while(temp1->next)
	{
	temp1=temp1->next;	
	}
	temp1->next = temp;
}
//////////////////////////////////////////////////
char uart_str[20];
u8 uart_check(void)
{
		u8 month,day,hour,min,sec;
	char *str = RxBuffer;
	char temp[20]={0};
	if(strlen(str) ==22)
	{
		memcpy(temp,str,4);
		if((strcmp(temp,"VNBR")!=0)&&(strcmp(temp,"CNBR")!=0))
		{
			return 0;
		}
		if(str[4]!=':' || str[9]!=':')
		{
			return 0;
		}
		str = RxBuffer;
		str+=12;
	month = (str[0]-'0')*10+(str[1]-'0');
	str+=2;
	day = (str[0]-'0')*10+(str[1]-'0');
	str+=2;
	hour = (str[0]-'0')*10+(str[1]-'0');
	str+=2;
	min = (str[0]-'0')*10+(str[1]-'0');
	str+=2;
	sec = (str[0]-'0')*10+(str[1]-'0');
	if((month > 12 )||(day>31)||(hour>=24)||(min>60)||(sec>60))
	{
		return 0;
	}
	  return 1;
	}
	else
	{
		return 0;
	}
}
u8 month_str[20]={31,29,31,30,31,30,31,31,30,31,30,31};

void uart_calc(Car_info* temp)
{
	float money=0;
	u32 htime,time,intime,outtime;
	u8 month,day,hour,min,sec;
	char *str = temp->intime;
	str+=2;
	month = (str[0]-'0')*10+(str[1]-'0');
	str+=2;
	day = (str[0]-'0')*10+(str[1]-'0');
	str+=2;
	hour = (str[0]-'0')*10+(str[1]-'0');
	str+=2;
	min = (str[0]-'0')*10+(str[1]-'0');
	str+=2;
	sec = (str[0]-'0')*10+(str[1]-'0');
	intime = month_str[month-1]*3600*24+day*24*3600+hour*3600+min*60+sec;
	str = temp->outtime;
	str+=2;
	month = (str[0]-'0')*10+(str[1]-'0');
	str+=2;
	day = (str[0]-'0')*10+(str[1]-'0');
	str+=2;
	hour = (str[0]-'0')*10+(str[1]-'0');
	str+=2;
	min = (str[0]-'0')*10+(str[1]-'0');
	str+=2;
	sec = (str[0]-'0')*10+(str[1]-'0');
	outtime = month_str[month-1]*3600*24+day*24*3600+hour*3600+min*60+sec;	
	time = outtime - intime;
	htime = time /3600;
	if(time %3600 !=0)
		htime++;
	if(temp->type == 0)
		money = htime * cnbr_fl;
	else if(temp->type == 1)
	money = htime * vnbr_fl;
	if(temp->type == 0)
	{
	sprintf(uart_str,"CNBR:%s:%d:%.2f\r\n",temp->num,htime,money);
	uart_print(uart_str);
	}
	else if(temp->type == 1)
	{
		sprintf(uart_str,"VNBR:%s:%d:%.2f\r\n",temp->num,htime,money);
		uart_print(uart_str);
	}
}
void dm(u32 nTime);
void uart_handle(void)
{

	char *temp = RxBuffer;char str[10]={0};
	Car_info* car_temp1=0;
	temp =strstr(temp,":");
	temp+=1;
	if(!uart_check())
	{
		dm(100);
		uart_print("Error\r\n");
		return ;
	}
	memcpy(str,temp,4);
	car_temp1 = car_find(str);
	if(car_temp1)
	{
		temp = RxBuffer;
		temp =strstr(temp,":");
		temp+=1;
		temp =strstr(temp,":");
		temp+=1;
		memcpy(car_temp1->outtime,temp,12);
		uart_calc(car_temp1);
		
	if(car_temp1->type == 1)
		{
			if((vnbr>0)&&(vnbr<=8))
					vnbr--;
		
		}
	else if(car_temp1->type == 0)
		{
			if((cnbr>0)&&(cnbr<=8))
			cnbr--;
		}
				idle++;
		car_delete(car_temp1->num);


	}
	else
	{
	if(idle == 0)
	{
		return ;
	}
	else
	{
	Car_info* car_temp = car_create();
		temp =RxBuffer;
		if(temp[0]=='V')
		car_temp->type =1;
		else if(temp[0]=='C')
		car_temp->type =0;
		temp =strstr(temp,":");
		temp+=1;
		memcpy(car_temp->num,temp,4);
		temp =strstr(temp,":");
		temp+=1;
		memcpy(car_temp->intime,temp,12);
		car_add(car_temp);
		idle--;
		if(car_temp->type == 1)
		{
		if((vnbr>=0)&& (vnbr<8))
			vnbr++;
		}
		else if(car_temp->type == 0)
		{	
		if((cnbr>=0)&& (cnbr<8))
			cnbr++;
		}
	}	
	}
	
}
