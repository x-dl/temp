#ifndef __key_h
#define __key_h
#include "stm32f10x.h"
void key_init(void);
void key_scan(void);

#define key1_press GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)
#define key2_press GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_8)
#define key3_press GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)
#define key4_press GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_2)
extern  u8 key_num,key_flag;
#endif
