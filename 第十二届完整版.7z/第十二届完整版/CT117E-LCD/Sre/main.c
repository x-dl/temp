#include "stm32f10x.h"
#include "lcd.h"
#include "led.h"
#include "key.h"
#include "uart.h"
#include "pwm.h"
#include "show.h"
#include "smg.h"
#include "capture.h"
u32 TimingDelay = 0;

void dm(u32 nTime);
char str[20];
//Main Body'
u16 smg_num,smg_flag;
u8 smg_status =0;
	extern u32 systime;
int main(void)
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	SysTick_Config(SystemCoreClock/1000);

	dm(200);
	
	STM3210B_LCD_Init();
	LCD_Clear(Black);
	LCD_SetBackColor(Black);
	LCD_SetTextColor(White);
	led_init();
	key_init();
	uart_init();
	//capture_init();
	car_header_init();

	while(1)
	{
	if(key_flag ==1)
	{
		key_flag =0;
		key_scan();
	}
	if(uart_flag ==1)
	{
		uart_flag =0;
		uart_handle();

	}

	//show();
	sprintf(str,"systime :%d",systime);
	LCD_DisplayStringLine(Line0,(u8*)str);
	}


}


void dm(u32 nTime)
{
	TimingDelay = nTime;
	while(TimingDelay != 0);	
}
